using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace TimerTriggerFunction.ParallelForEachAsync
{
    public class Function1
    {
        private readonly ILogger _logger;
        private readonly List<City> _cities;
        private readonly HttpClient _client;

        public Function1(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<Function1>();
            _client = new HttpClient();
            _cities = new List<City>
            {
                new() { Name="Delhi", Country = "India"},
                new() { Name="Mumbai", Country = "India"},  
                new() { Name="Bangalore", Country = "India"}, 
                new() { Name="Hyderabad", Country = "India"}, 
                new() { Name="Pune", Country = "India"},
                new() { Name="Delhi", Country = "India"},
                new() { Name="Mumbai", Country = "India"},
                new() { Name="Bangalore", Country = "India"},
                new() { Name="Hyderabad", Country = "India"},
                new() { Name="Pune", Country = "India"},
                new() { Name="Delhi", Country = "India"},
                new() { Name="Mumbai", Country = "India"},
                new() { Name="Bangalore", Country = "India"},
                new() { Name="Hyderabad", Country = "India"},
                new() { Name="Pune", Country = "India"},
                new() { Name="Delhi", Country = "India"},
                new() { Name="Mumbai", Country = "India"},
                new() { Name="Bangalore", Country = "India"},
                new() { Name="Hyderabad", Country = "India"},
                new() { Name="Pune", Country = "India"}
            };
        }

        [Function("Function1")]
        public async Task RunAsync([TimerTrigger("*/20 * * * * *")]TimerInfo timerInfo)
        {
            var countries = await FindCountries();
            _logger.LogInformation($"Countries Count: {countries.Count}");
        }

        private async Task<List<string>> FindCountries()
        {
            var countries = new List<string>();
            //ParallelOptions parallelOptions = new()
            //{
            //    MaxDegreeOfParallelism = 10
            //};
            //await Parallel.ForEachAsync(_cities, parallelOptions, async (city, _) =>
            //{
            //    if (await GetCityAsync(city))
            //    {
            //        countries.Add(city.Country);
            //    }
            //});

            var tasks = _cities.Select(async city =>
            {
                if (await GetCityAsync(city))
                {
                    countries.Add(city.Country);
                }
            });
            await Task.WhenAll(tasks);

            return countries;
        }

        private async Task<bool> GetCityAsync(City city)
        {
            var response = await _client.GetAsync("https://api.zippopotam.us/us/33162");
            if (response.IsSuccessStatusCode)
            {
               var location = await response.Content.ReadAsStringAsync();
            }
            return await Task.FromResult(_cities.Any(p=>p.Name == city.Name));
        }
    }

    public class City
    {
        public string Name { get; set; }
        public string Country { get; set; }
    }
}


